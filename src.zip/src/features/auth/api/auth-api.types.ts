export type LogInDataType = {
    email: string
    password: string
    rememberMe?: boolean
    captcha?: string
}
