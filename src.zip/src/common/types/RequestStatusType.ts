export type RequestStatusType = "idle" | "loading" | "succeeded" | "failed"
