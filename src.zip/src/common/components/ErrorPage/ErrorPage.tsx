import React from "react"

export function ErrorPage() {
    return (
        <div className="error-page">
            <div>
                <h1>Oops!</h1>
                <p>Page not found 404</p>
            </div>
        </div>
    )
}
